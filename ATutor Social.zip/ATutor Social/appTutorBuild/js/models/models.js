
Ext.ns('tutor', 'tutor.models' , 'tutor.panel', 'tutor.stores', 'tutor.template', 'tutor.storage', 'tutor.views');

tutor.models.Prospect = Ext.regModel('Prospect', {
    fields: [
        {name: 'ActRoundNo',  type: 'int'}
        ,{name: 'ProjRoundNo',  type: 'int'}
		,{name: 'PickNo',  type: 'int'}
		,{name: 'DraftedBy',  type: 'string'}
		,{name: 'Name',  type: 'string'}
        ,{name: 'Position',   type: 'string'}
        ,{name: 'Year', type: 'string'}
        ,{name: 'College', type: 'string'}
        ,{name: 'Height', type: 'string'}
        ,{name: 'Weight', type: 'string'}
        ,{name: 'ArmLength', type: 'string'}
        ,{name: 'HandSize', type: 'string'}
        ,{name: 'Headshot', type: 'string'}
        ,{name: 'Analysis', type: 'string'}

    ]
    
    ,proxy: {
        type: 'ajax'
        ,url : 'http://draft.philadelphiaeagles.com/prospects/json'
        ,reader: {
            type: 'json'
            ,root: 'data'
        }
    }
});

tutor.models.Pick = Ext.regModel('Pick', {
    fields: [
        
        {name: 'RoundNo',  type: 'int'}
		,{name: 'PickNo',  type: 'int'}
        ,{name: 'Name',  type: 'string'}
		,{name: 'Position',   type: 'string'}
        ,{name: 'Year', type: 'string'}
        ,{name: 'College', type: 'string'}
        ,{name: 'Height', type: 'string'}
        ,{name: 'Weight', type: 'string'}
        ,{name: 'ArmLength', type: 'string'}
        ,{name: 'HandSize', type: 'string'}
        ,{name: 'Headshot', type: 'string'}
        ,{name: 'Analysis', type: 'string'}

    ]
    
    ,proxy: {
        type: 'ajax'
        ,url : 'http://draft.philadelphiaeagles.com/draft_picks/json'
        ,reader: {
            type: 'json'
            ,root: 'data'
        }
    }
});





// ATSOCIAL Models BEGIN

tutor.models.Activity = Ext.regModel('Activity', {
    fields: [ 'postedTime', 'title','userId'],
    idProperty: 'activity',
});



tutor.models.Users = Ext.regModel('Users', {
    fields: ['id', 'displayName', 'url', 'profileUrl'],
    idProperty: 'users',
});

tutor.models.Gadgets = Ext.regModel('Gadgets', {
    fields: ['url', 'description' ],
    
    // proxy: {
    //        type: 'ajax',
    //        url : 'http://avipar.xtreemhost.com/ats/ats/gadget.json',
    //        reader: {
    //            type: 'json',
    //            root: 'entry'
    //        }
    //    }
});


tutor.models.Profile = Ext.regModel('Profile', {
    fields: ['id', 'displayName', 'link', 'profileUrl'],
});




tutor.models.More = Ext.regModel('More', {
    fields: ['head', 'description'],
    
    proxy: {
        type: 'ajax',
        url : 'more.json',
        reader: {
            type: 'json',
            root: 'entry'
        }
    }
});

