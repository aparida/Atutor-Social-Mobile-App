/*VideosCard.js*/Ext.ns("Atutor.views");


Atutor.views.ActivityCard = Ext.extend(Ext.Panel, {
    layout: 'fit'

    ,initComponent: function() {
    			 	
			
			
    		    			         var toolbarBase = {
    		    			             xtype: 'toolbar',
    		    			             title: 'My Activity',
    		    			             // ui: 'light',
    		    			 items: [{
    		    			                     xtype: "spacer",
    		    			                     flex: 1
    		    			                 }, {
    		    			                     ui: "button",
    		    			 					text: "Logout",
    		    			                     // iconCls: "action",
    		    			                     iconMask: true,
    		    			                     scope: this,
    		    			                     handler: function (a, b) {
    		    			 							
    		    			 							this.destroy();
    		    			 							Ext.Ajax.request({
    		    			 								url: 'http://' + tutor.myurl + '/logout.php', 
    		    			 								method: 'GET',
    		    			 								scope: this
    		    			 							});
    		    			 							
    		    			                         Ext.dispatch({
    		    			                             controller: "auth",
    		    			                             action: "logout",
    		    			                          
    		    			                         })
    		    			                     }
    		    			                 }]
    		    			         };
    		    			         
    		    			         this.dockedItems = toolbarBase;
    		
    	this.store = new Ext.data.Store({
		    model: 'Activity',
		    storeID: 'activity',
			proxy: {
		        type: 'ajax',
		        url :  'http://' + tutor.socialurl +  '/shindig/php/social/rest/activities/'+ tutor.badgeText + '/@self',
		        reader: {
		            type: 'json',
		            root: 'entry'
		        }
		    }
		});
    	// this.store.load();
    	this.ActivityList = new Ext.List({
			
    		store: this.store,
    		loadingText: 'Loading Activity',
    		disableSelection: true,
    		scroll: 'vertical',
        	itemTpl: '<a>You</a><strong> {title}</strong><br>{postedTime}',
        	
			plugins: [{
                ptype: 'listpaging',
                autoPaging: false,
				loadMoreText : 'List ends'
            }, {
                ptype: 'pullrefresh',
				pullRefreshText: 'Pulldown to refresh',
			
            }]
        });
    	
	
		this.items = [this.ActivityList];
		
        Atutor.views.ActivityCard.superclass.initComponent.apply(this, arguments);
        
        this.on('activate', function() {
                     	this.store.load();
                     }, this, {single: true});
    }
    
});


Ext.reg('activity', Atutor.views.ActivityCard);
