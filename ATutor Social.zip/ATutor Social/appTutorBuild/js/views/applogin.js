Ext.ns('tutor', 'tutor.panel', 'tutor.store', 'tutor.template', 'tutor.storage', 'tutor.views');


tutor.views.Login = Ext.extend(Ext.form.FormPanel, {

	id: 'loginform',
	fullscreen: true,
    modal: false,
    scroll: 'vertical',

       

    initComponent: function() {
	
		
	
	
		   this.dockedItems =  [{
	            xtype: "toolbar",
	            dock: "bottom",
	            ui: "gray",
	            items: [{
	                text: "Instructions",
	                handler: function () {
							// this.destroy();
	                    	new tutor.panel.Instructions().show('pop');
	
	                   	             
	                }
	            }, {
	                xtype: "spacer"
	            }, {
					xtype: "button",
			      
			        scope: this,
			        formBind: true,
	                text: "Login to ATutor Social",
	                ui: "confirm",
	                handler: function () {
						var b = new Ext.LoadMask("loginform", {
					            msg: "Please wait..."
					        });
							b.show();
							
						
						tutor.username = this.username.getValue();
						tutor.myurl = this.baseUrl.getValue();
						tutor.mypassword = this.password.getValue();
						tutor.socialurl = this.shingdigUrl.getValue();
						// tutor.url = this.baseUrl.getValue();
						tutor.toggle = this.destroyToggle.getValue();
						
						
					
							
							
						if (this.username.getValue() == "" || this.password.getValue() == ""){
							b.hide();
							Ext.Msg.alert("Login Error"," Please enter valid Username and Password.");
							
						}
					
						if ( this.baseUrl.getValue() == "" || this.shingdigUrl.getValue() == ""){
							b.hide();
							Ext.Msg.alert("Login Error"," Please enter the correct Base Url and Social Url.");
							
			     		}
					
						else {
							Ext.Ajax.request({
						
								url: 'http://' + tutor.myurl +'/login.php',
								params : { 
										submit: 1,
										token: '45ab234sdfh305',
										action: 'get',
										auto: 1,
										p: 'mods/_standard/social/memberid.php',
										form_login: this.username.getValue(),
										form_password_hidden: hex_sha1(hex_sha1(this.password.getValue()) + '45ab234sdfh305'),
										},
								method: 'POST',
								success: function (e) {
																	
												
												 
													
												var obj = Ext.util.JSON.decode(e.responseText);
												
												if (obj ) {
														Ext.Msg.alert('Login Success', "You are logged In");
												
														tutor.badgeText = obj;	
														b.hide();
														Ext.dispatch({
							                       			controller: "auth",
							               					action: "login"
							                            });
														
														
														this.destroy();
													
														}
															
												else if (!obj) {
															Ext.Msg.alert("Login Error"," Please enter valid Username and Password.");
														}				
													} ,
																							
								failure: function (e) { 
										
										Ext.Msg.alert("Log in error"," Please connect to the internet try again.");
										b.hide();
													},				
																							
																							 
								scope: this
							});
							
						
						}	                      
								
											
	                }
	            }]
	        }]
      
     		


 
	      this.username = new Ext.form.Text({
	          	name: "username",
				id: 'username',
              	label: "Username",
              	useClearIcon: true,
              	autoCapitalize: false,
				value: tutor.username
			
			
			
	       });
	       this.password = new Ext.form.Password({
	           name: 'password',
	           label: 'Password',
	           id: 'password',
				useClearIcon: true,
				autoCapitalize: false,
				value: tutor.mypassword
		    
	       });
	       this.shingdigUrl = new Ext.form.Text({
	           name: 'shindig_url',
	           label: 'Social URL',
	           id: 'shindigURL',
				useClearIcon: true,
              	autoCapitalize: false,
				value: 'social.atutor.ca',
				placeHolder: 'social.atutor.ca',
			
	       });
		this.baseUrl = new Ext.form.Text({
	           name: 'baseUrl',
	           label: 'URL',
	           id: 'baseUrl',
				useClearIcon: true,
              	autoCapitalize: false,
				value: 'atutor.ca/atutor/demo',
				placeHolder : 'atutor.ca/atutor/demo',
			
	       });
  
		this.destroyToggle = new Ext.form.Toggle({
			id: 'toggle_me',
			label : 'Remember',	
			maxValue: 1,
			minValue: 0,
			autoDestroy: true,
			height: 10,
			maxHeight: 10,
		});
			


			this.logo =	new Ext.Panel({
	                items: {
	                    styleHtmlContent: true,
	                    tpl: new Ext.Template(['<div class="section centered">', '<div><img style="margin: -20px 0 0 0;" src="img/atlogo.png"  width="{width}"  alt="atutor" /></div>', '<div class="blurb">', "", '<div class="tip" style="font-size:14px;margin:5px 0 0 0;">', "<strong>Social</strong>","</div>", '<div style="font-size:11px;" >'," ", "</div>", "</div>", "</div>"]),
	                    data: {
	                        width: 150,
	                    }
	                },
	            

				});


	       this.fs = new Ext.form.FieldSet({
			instructions: 'Please enter your login name or your email address, and your password.',
				width: '80%',
	 			items: [this.username, this.password]
	       });
	
	
		 this.urls = new Ext.form.FieldSet({
			instructions: 'Please enter your Base Url and ShinDig Url',
				width: '80%',
	 			items: [this.baseUrl, this.shingdigUrl]
	       });
	
		this.baseUrl,
			
	       this.items = [this.fs,this.urls];
	
	
		
	
	

	  if (Ext.is.Phone) {
	        Ext.apply(tutor.views.Login, {
	            fullscreen: true,
	            modal: false
	        })
	    } else {
	        Ext.apply(tutor.views.Login, {
	            autoRender: true,
	            floating: true,
	            modal: true,
	            centered: true,
	            hideOnMaskTap: false,
	            height: 385,
	            width: 440
	        })
	    }
  
	    tutor.views.Login.superclass.initComponent.apply(this, arguments);

	}

});


Ext.reg('login', tutor.views.Login);



