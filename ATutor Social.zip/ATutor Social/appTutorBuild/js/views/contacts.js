/*VideosCard.js*/Ext.ns("Atutor.views");

Atutor.views.ContactCard = Ext.extend(Ext.Panel, {
    layout: 'fit'
    ,initComponent: function() {
    	
        var toolbarBase = {
            xtype: 'toolbar',
            title: 'Contacts',
            // ui: 'light',
			 items: [{
                    xtype: "spacer",
                    flex: 1
                }, {
                    ui: "button",
                    // iconCls: "delete",
					text: "Groups",
                    iconMask: true,
                    scope: this,
                    handler: function () {
						       // Ext.dispatch({
						       // 			                                     controller: "auth",
						       // 			                                     action: "login"
						       // 			                                     })        
							 
								
								new tutor.panel.Groups().show('pop');	
						                
						                       }
                }]
        };
        
        this.dockedItems = toolbarBase;

    	this.store = new Ext.data.Store({
		    model: 'Users',
		    storeID: 'users',
			sorters: 'displayName',
		    getGroupString : function(record) {
			        return record.get('displayName')[0];
			    },
			proxy: {
		        type: 'ajax',
		        url :  'http://' + tutor.socialurl +  '/shindig/php/social/rest/people/'+ tutor.badgeText + '/@all',
		        reader: {
		            type: 'json',
		            root: 'entry'
		        }
		    }
		});
    
    	this.ContactList = new Ext.List({
			
			grouped: true,
            indexBar: true,
    		store: this.store,
    		loadingText: 'Loading Contacts',
    		disableSelection: true,
    		scroll: 'vertical',
        	itemTpl: '<strong>{displayName}</strong><br/> <font style="font-size:12px; color: #000;">&nbsp;User ID: {id}  </font>',
        		// itemTpl: '<strong>{displayName}</strong> ',
			
        });
    	
				
		this.items = [this.ContactList];
		
        Atutor.views.ContactCard.superclass.initComponent.apply(this, arguments);
        
        this.on('activate', function() {
        	this.store.load();
        }, this, {single: true});
    }
    
});


Ext.reg('contact', Atutor.views.ContactCard);
