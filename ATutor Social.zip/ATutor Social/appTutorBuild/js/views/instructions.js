Ext.ns('tutor', 'tutor.panel', 'tutor.store', 'tutor.template', 'tutor.storage', 'tutor.views');


tutor.panel.Instructions = Ext.extend(Ext.Panel, {
    floating: true,
    modal: true,
    centered: true,
    width: 280,
	height:380,
    scroll: 'vertical',
	 html: '<p style="padding: 15px 0 0 0;text-align:center;font-size: 26px;color: #cccccc;font-weight:bold;">Instructions</p><br/><p style="text-align:center;font-size: 16px;color: #cccccc;" >This allows you to access your groups and its members.Lorem This allows you to access your groups and its members.This allows you to access your groups and its members.This allows you to access your groups and its members.This allows you to access your groups and its members.This allows you to access your groups and its members.This allows you to access your groups and its members.This allows you to access your groups and its members.</p>'
   
});