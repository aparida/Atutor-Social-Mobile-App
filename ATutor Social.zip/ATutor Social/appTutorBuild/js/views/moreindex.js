Ext.ns('tutor', 'tutor.panel', 'tutor.store', 'tutor.template', 'tutor.storage', 'tutor.views');

tutor.views.MoreIndex = Ext.extend(Ext.Panel, {
    id: "moreindex",
    layout: "card",
	fullscreen: true,
    initComponent: function () {
        this.list = new Ext.Panel({
            scroll: "vertical",
            items: [new Ext.Panel({
                items: {
                    styleHtmlContent: true,
                    tpl: new Ext.Template(['<div class="section centered">', '<div><img src="img/atlogo.png"  width="{width}"  alt="atutor" /></div>', '<div class="blurb">', "", '<div class="tip">', "<strong>Social</strong> Students learn in an accessible, adaptive, social learning environment.", "</div>", "</div>", "</div>"]),
                    data: {
                        width: 160,
                        height: 60,
                       
                    }
                },
                dockedItems: {
                    xtype: "toolbar",
                    title: "ATutor Social",
                    ui: "light",
                    cls: "small_title"
                }
           
			}),	new Ext.Panel({
	                items: {
	                    styleHtmlContent: true,
	                     html: ['<div class="section centered">', '<div class="blurb">', 'Connect with your friends instantly. Atutor Social is developed for <a href="http://atutor.ca/atutor/" rel="external">Atutor LMS</a>.', "</div>", "</div>"].join("")
	                },
	                dockedItems: {
	                    xtype: "toolbar",
	                    title: "About Atutor",
	                    ui: "light",
	                    cls: "small_title"
	                }
            }), new Ext.Panel({
                items: {
                    styleHtmlContent: true,
                    html: ['<div class="section centered">', '<div class="blurb">', 'The Inclusive Design Institute, the developer of ATutor, is a not-for-profit organization support open source development projects, and keeps its software free. Please consider making a donation. <a href="http://atutor.ca/payment/index.php?project=ATutor-Donation" rel="external">Donate Now</a>.', "</div>", "</div>"].join("")
                },
                dockedItems: {
                    xtype: "toolbar",
                    title: "Atutor Donation",
                    ui: "light",
                    cls: "small_title"
                }
            })],
            dockedItems: [{
                xtype: "toolbar",
                title: "More",
                items: [{
                    xtype: "spacer",
                    flex: 1
                }, {
                    ui: "button",
                    text: "Logout",
                    scope: this,
                    handler: function (a) {
                     		this.destroy();
 							Ext.Ajax.request({
 								url: 'http://' + tutor.myurl + '/logout.php', 
 								method: 'GET',
 								scope: this
 							});
 							
                         Ext.dispatch({
                             controller: "auth",
                             action: "logout",
                          
                         })
                    }
                }]
            }]
        });
        Ext.apply(this, {
            items: [this.list]
        });
        tutor.views.MoreIndex.superclass.initComponent.call(this, arguments)
    },
});
Ext.reg("moreindex", tutor.views.MoreIndex);
